controls:

Escape: Quit
backspace: Spawn enemy
F12: Show collision boxes

left: move left
right: move right
up: jump

enter: shoot projectile